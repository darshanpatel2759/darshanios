//
//  RecipeCell.swift
//  foodylover
//
//  Created by MSCICT2 on 15/05/24.
//

import UIKit

class RecipeCell: UITableViewCell {

    @IBOutlet weak var foodimag : UIImageView!
    @IBOutlet weak var foodname : UILabel!

}
