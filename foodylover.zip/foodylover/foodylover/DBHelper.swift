//
//  DBHelper.swift
//  foodylover
//
//  Created by MSCICT2 on 15/05/24.
//

import Foundation
import SQLite3

var db:DBhelper = DBhelper()

class DBhelper
{
    init(){
        
        db = opendatabase()
        createtable()
    }
    
    let dbpath : String = "fooddb.sqlite"
    var db : OpaquePointer?
    
    func opendatabase() -> OpaquePointer?{
        
        let fileURl = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) .appendingPathComponent(dbpath)
        
        var db : OpaquePointer? = nil
        if sqlite3_open(fileURl.path, &db) != SQLITE_OK
        {
            print("error opening database")
            return nil
        }
        else
        {
            print("successfully opened connection to databse at \(dbpath)")
            print("\(fileURl)")
            return db
        }
        
    }
    
    func createtable(){
        
        let recipetbl = "CREATE TABLE IF NOT EXISTS recipe(rid INTEGER PRIMARY KEY,fname TEXT,ftype TEXT,desc TEXT,ctime TEXT,people INTEGER,ingredient TEXT,instruction TEXT,fimg TEXT);"
        
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, recipetbl, -1, &stmt, nil) == SQLITE_OK
        {
            if sqlite3_step(stmt) == SQLITE_DONE
            {
                print("table create")
            }
            else{
                print("table not create")
            }
        }else{
            print("create table statement could not be prepared")
        }
        
        sqlite3_finalize(stmt)
    }
    
    func insertdata(fname: String, ftype: String, desc: String, ctime: String, people: Int, ingredient: String, instruction: String, fimg: String)
    {
        let insertdata = "insert into recipe(rid, fname, ftype, desc, ctime, people, ingredient, instruction, fimg) VALUES (?,?,?,?,?,?,?,?,?);"
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, insertdata, -1, &stmt, nil) == SQLITE_OK{
            
            sqlite3_bind_text(stmt, 2, (fname as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 3, (ftype as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 4, (desc as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 5, (ctime as NSString).utf8String, -1, nil)
            sqlite3_bind_int(stmt, 6, Int32(people))
            sqlite3_bind_text(stmt, 7, (ingredient as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 8, (instruction as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 9, (fimg as NSString).utf8String, -1, nil)
            
            
            if sqlite3_step(stmt) == SQLITE_DONE{
                print("insert data successfully")
            }
            else
            {
                print("could not insert data")
            }
        }else{
            print("insert statement not prepared")
        }
        sqlite3_finalize(stmt)
    }
    
    func showdata() -> [Recipe]
    {
        var arrofrecipe = [Recipe]()
        arrofrecipe.removeAll()
        
        let qry = "select * from recipe"
        
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, qry, -1, &stmt, nil) == SQLITE_OK{
        
            while(sqlite3_step(stmt) == SQLITE_ROW){
                
                let rid = sqlite3_column_int(stmt, 0)
                let fname = String(cString: sqlite3_column_text(stmt, 1))
                let ftype = String(cString: sqlite3_column_text(stmt, 2))
                let desc = String(cString: sqlite3_column_text(stmt, 3))
                let ctime = String(cString: sqlite3_column_text(stmt, 4))
                let people = sqlite3_column_int(stmt, 5)
                let ingredient = String(cString: sqlite3_column_text(stmt, 6))
                let instruction = String(cString: sqlite3_column_text(stmt, 7))
                let fimg = String(cString: sqlite3_column_text(stmt, 8))
                
                arrofrecipe.append(Recipe(rid: Int(rid), fname: String(fname), ftype: String(ftype), desc: String(desc), ctime: String(ctime), people: Int(people), ingredient: String(ingredient), instruction: String(instruction), fimg: String(fimg)))
            }
            return arrofrecipe
        }
        
        return arrofrecipe
    }
    
    func delete(rid :Int){
        
        let delqry = "delete from recipe where rid = ?;"
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, delqry, -1, &stmt, nil) == SQLITE_OK{
            
            if sqlite3_step(stmt) == SQLITE_DONE{
                
                print("delete row")
            }else
            {
                print("not delete")
            }
        }else
        {
            print("delete statement not prepared")
        }
        sqlite3_finalize(stmt)
    }
    
    func update(rid: Int,fname: String, ftype: String, desc: String, ctime: String, people: Int, ingredient: String, instruction: String, fimg: String)
    {
        
        let editqry = "update recipe set fname = '\(fname)', ftype = '\(ftype)', desc = '\(desc)', ctime = '\(ctime)', people = '\(people)', ingredient = '\(ingredient)', instruction = '\(instruction)', fimg = '\(fimg)' where rid = '\(rid)';"
        
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, editqry, -1, &stmt, nil) == SQLITE_OK{
            if sqlite3_step(stmt) == SQLITE_DONE{
                print("update data successfully")
            }else{
                print("update not done")
            }
        }else{
            print("update statement not prepared")
        }
        sqlite3_finalize(stmt)
    }
}
