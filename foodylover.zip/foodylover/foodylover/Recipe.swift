//
//  Recipe.swift
//  foodylover
//
//  Created by MSCICT2 on 15/05/24.
//

import Foundation
import UIKit

class Recipe{
    
    var rid : Int!
    var fname : String!
    var ftype : String!
    var desc : String!
    var ctime : String!
    var people : Int!
    var ingredient : String!
    var instruction : String!
    var fimg : String!
    
    init(rid: Int, fname: String, ftype: String, desc: String, ctime: String, people: Int, ingredient: String, instruction: String, fimg: String) {
        self.rid = rid
        self.fname = fname
        self.ftype = ftype
        self.desc = desc
        self.ctime = ctime
        self.people = people
        self.ingredient = ingredient
        self.instruction = instruction
        self.fimg = fimg
    }
}
