//
//  ViewController.swift
//  foodylover
//
//  Created by MSCICT2 on 15/05/24.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{

    @IBOutlet weak var foodtbl : UITableView!
    
    var arrofrecipe = [Recipe]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.foodtbl.reloadData()
        arrofrecipe = db.showdata()
        
        
        self.navigationController?.navigationBar.isHidden = true
    }

    
    @IBAction func backctn(_ sender : UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func addbtn(_ sender : UIButton){
        
        let vc = storyboard?.instantiateViewController(withIdentifier: "AddrecipeVC") as! AddrecipeVC
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrofrecipe.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cell = tableView.dequeueReusableCell(withIdentifier: "RecipeCell", for: indexPath) as! RecipeCell
        
        DispatchQueue.main.async {
            if let decodedData = Data(base64Encoded: self.arrofrecipe[indexPath.row].fimg) {
                if let decodedImage = UIImage(data: decodedData) {
                    print("Decoded Image: \(decodedImage)")
                    // Use the decoded image as needed
                    cell.foodimag.image = decodedImage
                }
            }
        }
        
        //cell.foodimag.image = arrofrecipe[indexPath.row].fimg
        cell.foodname.text = arrofrecipe[indexPath.row].fname
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 201
    }
}

extension UIImage {

    public var base64: String {
        return self.jpegData(compressionQuality: 1.0)!.base64EncodedString()
    }

    convenience init?(base64: String, withPrefix: Bool) {
        var finalData: Data?

        if withPrefix {
            guard let url = URL(string: base64) else { return nil }
            finalData = try? Data(contentsOf: url)
        } else {
            finalData = Data(base64Encoded: base64)
        }

        guard let data = finalData else { return nil }
        self.init(data: data)
    }

}
