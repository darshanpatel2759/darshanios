//
//  AddrecipeVC.swift
//  foodylover
//
//  Created by MSCICT2 on 15/05/24.
//

import UIKit

class AddrecipeVC: UIViewController {
    
    @IBOutlet weak var txtfname : UITextField!
    @IBOutlet weak var txtftype : UITextField!
    @IBOutlet weak var txtdesc : UITextView!
    @IBOutlet weak var txtctime : UITextField!
    @IBOutlet weak var txtpeople : UITextField!
    @IBOutlet weak var txtingredient : UITextView!
    @IBOutlet weak var txtinstruction : UITextView!
    @IBOutlet weak var fimg : UIImageView!
    
    var strBase64:String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    @IBAction func backbtn(_ sender : UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func fimagebtn(_ sender : UIButton){
        
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        self.present(vc, animated: true)
        
    }
    
    @IBAction func addbtn(_ sender : UIButton){
        
        DispatchQueue.main.async {
            if let imageData = self.fimg.image?.pngData() {
                self.strBase64 = imageData.base64EncodedString()
            }
            
            db.insertdata(fname: self.txtfname.text ?? "", ftype: self.txtftype.text ?? "", desc: self.txtdesc.text ?? "", ctime: self.txtctime.text ?? "", people: Int(self.txtpeople.text ?? "") ?? 0, ingredient: self.txtingredient.text ?? "", instruction: self.txtinstruction.text ?? "", fimg: self.strBase64)
            
            
            self.navigationController?.popViewController(animated: true)
        }
    }
}

extension AddrecipeVC : UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")]as? UIImage{
            
            fimg.image = image
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
