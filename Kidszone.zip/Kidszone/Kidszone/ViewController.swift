//
//  ViewController.swift
//  Kidszone
//
//  Created by MSCIT on 20/05/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtname : UITextField!
    @IBOutlet weak var txtage : UITextField!
    @IBOutlet weak var txtcity : UITextField!
    @IBOutlet weak var btnboy : UIButton!
    @IBOutlet weak var btngirl : UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
       
        
        
        //let value = UserDefaults.standard.string(forKey: "name")
        self.navigationController?.navigationBar.isHidden = true
    }

    @IBAction func btngender(_ sender : UIButton){
        
        if sender.tag == 1{
            
            UserDefaults.standard.setValue(1, forKey: "gender")
            btngirl.layer.borderColor = UIColor.blue.cgColor
            btngirl.layer.borderWidth = 3
            btnboy.layer.borderWidth = 0
            
        }else{
            
            UserDefaults.standard.setValue(0, forKey: "gender")
            btnboy.layer.borderColor = UIColor.blue.cgColor
            btnboy.layer.borderWidth = 3
            btngirl.layer.borderWidth = 0
        }
    }
    
    @IBAction func btnnext(_ sender : UIButton){
        let ageval : Int = Int(txtage.text ?? "") ?? 0
        
        if ageval < 4 || ageval > 12 {
            
            let alert = UIAlertController(title: "Error", message: "Age Between 4 to 12", preferredStyle: .alert)
            let okbutton = UIAlertAction(title: "ok", style: .default)
            alert.addAction(okbutton)
            present(alert, animated: true)
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
            self.navigationController?.pushViewController(vc, animated: true)
            
        }else{
            
            UserDefaults.standard.setValue(txtname.text ?? "", forKey: "name")
            UserDefaults.standard.setValue(txtage.text ?? "", forKey: "age")
            UserDefaults.standard.setValue(txtcity.text ?? "", forKey: "city")
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "homeVC") as! homeVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
   
        
    }

    @IBAction func btnsetting(_ sender : UIButton){
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "settingVC") as! settingVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

