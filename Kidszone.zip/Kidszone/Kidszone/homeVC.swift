//
//  homeVC.swift
//  Kidszone
//
//  Created by MSCIT on 20/05/24.
//

import UIKit

class homeVC: UIViewController {
    
    @IBOutlet weak var imgbaby : UIImageView!
    @IBOutlet weak var lblname : UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        let value = UserDefaults.standard.string(forKey: "name")
        
        if value != nil{
            
            lblname.text = "Hello Baby \(value!)"
        }
        
        if UserDefaults.standard.integer(forKey: "gender") == 1{
            
            imgbaby.image = UIImage(named: "girl")
            
        }else{
            
            imgbaby.image = UIImage(named: "boy")
        }

    }
    
    @IBAction func btnback(_ sender : UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func btnnext(_ sender : UIButton){
        
        
    }
    
    @IBAction func btnlearn(_ sender : UIButton){
        
        if sender.tag == 1{
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "home1VC") as! home1VC
            self.navigationController?.pushViewController(vc, animated: true)
            
        }else if sender.tag == 2{
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "home2VC") as! home2VC
            self.navigationController?.pushViewController(vc, animated: true)
            
        }else if sender.tag == 3{
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "worksheetVC") as! worksheetVC
            self.navigationController?.pushViewController(vc, animated: true)
            
        }else{
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "home3VC") as! home3VC
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    

}
