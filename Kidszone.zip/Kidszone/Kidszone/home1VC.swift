//
//  home1VC.swift
//  Kidszone
//
//  Created by MSCIT on 20/05/24.
//

import UIKit

class home1VC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnback(_ sender : UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }

}
