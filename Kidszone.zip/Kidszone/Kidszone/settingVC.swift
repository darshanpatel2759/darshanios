//
//  settingVC.swift
//  Kidszone
//
//  Created by MSCIT on 20/05/24.
//

import UIKit

class settingVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    
    @IBAction func btnback(_ sender : UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }

}
