//
//  home3VC.swift
//  Kidszone
//
//  Created by MSCIT on 21/05/24.
//

import UIKit

class home3VC: UIViewController, UITableViewDelegate, UITableViewDataSource {
   
    
    var arrofabc : [abckids] = [abckids(title: "A", header: "a", main: "Apple \n apple", img: UIImage(named: "apple")),
        abckids(title: "B", header: "b", main: "Ball", img: UIImage(named: "ball")),
        abckids(title: "C", header: "c", main: "Cat",img: UIImage(named: "cat")),
        abckids(title: "D", header: "d", main: "Dog",img: UIImage(named: "dog")),
        abckids(title: "E", header: "e", main: "Elephant",img: UIImage(named: "elephant")),
        abckids(title: "F", header: "f", main: "Fan",img: UIImage(named: "fan")),
        abckids(title: "G", header: "g", main: "Grapes",img: UIImage(named: "grapes")),
        abckids(title: "H", header: "h", main: "House",img: UIImage(named: "house")),
        abckids(title: "I", header: "i", main: "Ice Cream",img: UIImage(named: "ice cream")),
        abckids(title: "J", header: "j", main: "Joker",img: UIImage(named: "joker")),
        abckids(title: "K", header: "k", main: "King",img: UIImage(named: "king")),
        abckids(title: "L", header: "l", main: "Lion",img: UIImage(named: "lion")),
        abckids(title: "M", header: "m", main: "Mango",img: UIImage(named: "mango")),
        abckids(title: "N", header: "n", main: "Nest",img: UIImage(named: "nest")),
        abckids(title: "O", header: "o", main: "Orange",img: UIImage(named: "orange")),
        abckids(title: "P", header: "p", main: "Parrot",img: UIImage(named: "parrot")),
        abckids(title: "Q", header: "q", main: "Queen",img: UIImage(named: "queen")),
        abckids(title: "R", header: "r", main: "Rat",img: UIImage(named: "rat")),
        abckids(title: "S", header: "s", main: "Swan",img: UIImage(named: "swan")),
        abckids(title: "T", header: "t", main: "Tree",img: UIImage(named: "tree")),
        abckids(title: "U", header: "u", main: "Umbrella",img: UIImage(named: "umbrela")),
        abckids(title: "V", header: "v", main: "Van",img: UIImage(named: "van")),
        abckids(title: "W", header: "w", main: "Watch",img: UIImage(named: "watch")),
        abckids(title: "X", header: "x", main: "X-mas Tree",img: UIImage(named: "x-mas tree")),
        abckids(title: "Y", header: "y", main: "Yak",img: UIImage(named: "yak")),
        abckids(title: "Z", header: "z", main: "Zebra",img: UIImage(named: "zebra"))]
    

   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnback(_ sender : UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrofabc.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ABCcell", for: indexPath) as! ABCcell
        cell.lbltitle.text = arrofabc[indexPath.row].title
        cell.lblheader.text = arrofabc[indexPath.row].header
        cell.lblmain.text = arrofabc[indexPath.row].main
        cell.img.image = arrofabc[indexPath.row].img
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 138
            
    }
    

}

struct abckids{
    
    let title : String?
    let header : String?
    let main : String?
    let img : UIImage?
}
