//
//  home2VC.swift
//  Kidszone
//
//  Created by MSCIT on 21/05/24.
//

import UIKit

class home2VC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func btnback(_ sender : UIButton){
        
        self.navigationController?.popViewController(animated: true)
    }
}
