//
//  worksheetCell.swift
//  Kidszone
//
//  Created by MSCIT on 21/05/24.
//

import UIKit

class worksheetCell: UITableViewCell {

    @IBOutlet weak var lblmain : UILabel!

}
