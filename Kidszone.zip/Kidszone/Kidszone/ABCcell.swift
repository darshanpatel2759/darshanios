//
//  ABCcell.swift
//  Kidszone
//
//  Created by MSCIT on 20/05/24.
//

import UIKit

class ABCcell: UITableViewCell {

    @IBOutlet weak var lbltitle : UILabel!
    @IBOutlet weak var lblheader : UILabel!
    @IBOutlet weak var lblmain : UILabel!
    @IBOutlet weak var img : UIImageView!
}
