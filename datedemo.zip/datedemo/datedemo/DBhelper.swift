//
//  DBhelper.swift
//  datedemo
//
//  Created by MSCIT on 22/05/24.
//

import Foundation
import SQLite3

var db : DBhelper = DBhelper()

class DBhelper{
    
    init()
    {
        db = opendatabase()
        createtable()
    }
    
    let dbpath : String = "studentdb.sqlite"
    var db : OpaquePointer?
    
    func opendatabase() -> OpaquePointer?{
        
        let fileurl = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathExtension(dbpath)
        var db : OpaquePointer? = nil
        
        if sqlite3_open(fileurl.path, &db) != SQLITE_OK{
            
            print("error in open database")
            return nil
            
        }else{
            
            print("database open success")
            print("\(fileurl)")
            return db
            
        }
        
    }
    
    func createtable()
    {
        let createtbl = "CREATE TABLE IF NOT EXISTS student(sid INTEGER PRIMARY KEY, uname TEXT, password TEXT, dob TEXT, proimg TEXT);"
        
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, createtbl, -1, &stmt, nil) == SQLITE_OK{
            
            if sqlite3_step(stmt) == SQLITE_DONE{
                
                print("table create")
            }else{
                
                print("table not create")
            }
        }else{
            
            print("create tabel statement not prepared")
        }
        sqlite3_finalize(stmt)
    }
    
    func insertdata(uname: String, password: String, dob: String, proimg: String){
        
        let qry = "insert into student(sid, uname, password, dob, proimg) VALUES (?,?,?,?,?);"
        
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, qry, -1, &stmt, nil) == SQLITE_OK{
            
            sqlite3_bind_text(stmt, 2, (uname as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 3, (password as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 4, (dob as NSString).utf8String, -1, nil)
            sqlite3_bind_text(stmt, 5, (proimg as NSString).utf8String, -1, nil)
            
            if sqlite3_step(stmt) == SQLITE_DONE{
                
                print("insert done")
            }else{
                print("insert not done")
            }
            
        }else{
            
            print("insert statement not proper")
        }
        sqlite3_finalize(stmt)
    }
    
    func showdata()-> [student]{
        
        var arrofstudent = [student]()
        arrofstudent.removeAll()
        
        let qry = "select * from student"
        
        var stmt : OpaquePointer? = nil
        
        if sqlite3_prepare_v2(db, qry, -1, &stmt, nil) == SQLITE_OK{
            
            while sqlite3_step(stmt) == SQLITE_ROW{
                
                let sid = sqlite3_column_int(stmt, 0)
                let uname = String(cString: sqlite3_column_text(stmt, 1))
                let password = String(cString: sqlite3_column_text(stmt, 2))
                let dob = String(cString: sqlite3_column_text(stmt, 3))
                let proimg = String(cString: sqlite3_column_text(stmt, 4))
                
                arrofstudent.append(student(sid: Int(sid), uname: String(uname), password: String(password), dob: String(dob), proimg: String(proimg)))
            }
            return arrofstudent
        }
        return arrofstudent
    }
}
