//
//  student.swift
//  datedemo
//
//  Created by MSCIT on 22/05/24.
//

import Foundation

class student{
    
    var sid : Int!
    var uname : String!
    var password : String!
    var dob : String!
    var proimg : String!
    
    init(sid: Int, uname: String, password: String, dob: String, proimg: String) {
        self.sid = sid
        self.uname = uname
        self.password = password
        self.dob = dob
        self.proimg = proimg
    }
}
