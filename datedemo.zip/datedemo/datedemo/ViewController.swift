//
//  ViewController.swift
//  datedemo
//
//  Created by MSCIT on 22/05/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var txtdate : UITextField!
    @IBOutlet weak var txtuname : UITextField!
    @IBOutlet weak var txtpassword : UITextField!
    @IBOutlet weak var proimg : UIImageView!
    
    var strBase64:String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
       
        self.navigationController?.navigationBar.isHidden = true
        txtdate.delegate = self
    }
    
    
    @IBAction func proimgbtn(_ sender : UIButton){
        
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        self.present(vc, animated: true)
        
    }
    
    @IBAction func btnreg(_ sender : UIButton){
        DispatchQueue.main.async {
            if let imageData = self.proimg.image?.pngData() {
                self.strBase64 = imageData.base64EncodedString()
            }
            db.insertdata(uname: self.txtuname.text ?? "", password: self.txtpassword.text ?? "", dob: self.txtdate.text ?? "", proimg: self.strBase64)
            
            self.txtuname.text = ""
            self.txtpassword.text = ""
            self.txtdate.text = ""
            self.proimg.image = UIImage(named: "person")
            
            //        let alert = UIAlertController(title: "Insert Done", message: "Data Insert Successfully", preferredStyle: .alert)
            //        let okbtn = UIAlertAction(title: "Done", style: .default)
            //        alert.addAction(okbtn)
            //        self.present(alert, animated: true, completion: nil)
            
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "homeVC") as! homeVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }

    @IBAction func btnShowList(_ sender : UIButton){
        let vc = storyboard?.instantiateViewController(withIdentifier: "homeVC") as! homeVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension ViewController : UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let image = info[UIImagePickerController.InfoKey(rawValue: "UIImagePickerControllerEditedImage")]as? UIImage{
            
            proimg.image = image
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}
extension ViewController : UITextFieldDelegate{
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        self.opendatepicker()
    }
}
extension ViewController{
    
    func opendatepicker(){
        
        let datepicker = UIDatePicker()
        datepicker.datePickerMode = .date
        
        txtdate.inputView = datepicker
        
        
        let toolbar = UIToolbar(frame: CGRect(x: 0, y: 0, width: self.view.frame.width, height: 44))
        let donebtn = UIBarButtonItem(title: "Done", style: .plain, target: self, action: #selector(self.donebtnclick))
        let cancelbtn = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(self.cancelbtnclick))
        let flexiblebtn = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        toolbar.setItems([cancelbtn, flexiblebtn, donebtn], animated: true)
        
        txtdate.inputAccessoryView = toolbar
    }
    
    @objc
    func donebtnclick(){
        
        if let datepicker = txtdate.inputView as? UIDatePicker{
            
            print(datepicker.date)
            let dateFormatter = DateFormatter()
            dateFormatter.dateStyle = .medium
            txtdate.text = dateFormatter.string(from: datepicker.date)
        }
    }
    
    @objc
    func cancelbtnclick(){
     
        txtdate.resignFirstResponder()
    }
    
}
