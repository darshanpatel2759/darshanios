//
//  studentCell.swift
//  datedemo
//
//  Created by MSCIT on 22/05/24.
//

import UIKit

class studentCell: UITableViewCell {

    @IBOutlet weak var lblname : UILabel!
    @IBOutlet weak var lbldob : UILabel!
    @IBOutlet weak var proimg : UIImageView!
    

}
