//
//  homeVC.swift
//  datedemo
//
//  Created by MSCIT on 22/05/24.
//

import UIKit

class homeVC: UIViewController , UITableViewDelegate, UITableViewDataSource{
    
    @IBOutlet weak var studenttbl : UITableView!
    
    var arrofstudent = [student]()

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        arrofstudent = db.showdata()
        self.studenttbl.reloadData()
    }
    
    @IBAction func btnBack(_ sender : UIButton){
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrofstudent.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "studentCell", for: indexPath) as! studentCell
        DispatchQueue.main.async {
            if let decodedData = Data(base64Encoded: self.arrofstudent[indexPath.row].proimg) {
                if let decodedImage = UIImage(data: decodedData) {
                    print("Decoded Image: \(decodedImage)")
                    // Use the decoded image as needed
                    cell.proimg.image = decodedImage
                }
            }
        }
        cell.lblname.text = arrofstudent[indexPath.row].uname
        cell.lbldob.text = arrofstudent[indexPath.row].dob
        
        return cell
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160
    }
    
}
extension UIImage {

    public var base64: String {
        return self.jpegData(compressionQuality: 1.0)!.base64EncodedString()
    }

    convenience init?(base64: String, withPrefix: Bool) {
        var finalData: Data?

        if withPrefix {
            guard let url = URL(string: base64) else { return nil }
            finalData = try? Data(contentsOf: url)
        } else {
            finalData = Data(base64Encoded: base64)
        }

        guard let data = finalData else { return nil }
        self.init(data: data)
    }

}
