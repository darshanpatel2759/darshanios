//
//  personcell.swift
//  databasedemo
//
//  Created by Darshan on 26/04/24.
//

import UIKit

class personcell: UITableViewCell {

    @IBOutlet weak var lblname : UILabel!
    @IBOutlet weak var lblage : UILabel!
    @IBOutlet weak var btnedit : UIButton!
    @IBOutlet weak var btndel : UIButton!

}
